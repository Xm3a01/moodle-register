<?php $__env->startSection('content'); ?>
  <table class="table col-md-10 offset-md-1 showusers">
   <thead>
    <tr>
    <th>#</th>
    <th>First name</th>
    <th>Last name</th>
    <th>Email</th>
    <th>User name</th>
    <!-- confirmed -->
    <th>confirmed | Email</th>
    <!-- mnethostid -->
    <th>Moodle network host id</th>
    <th>Course participate</th>
    <th>Status</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
   <td><?php echo e($user->id); ?></td>
   <td><?php echo e($user->firstname); ?></td>
   <td><?php echo e($user->lastname); ?></td>
   <td><?php echo e($user->email); ?></td>
   <td><?php echo e($user->username); ?></td>
   <td><?php echo e($user->confirmed); ?></td>
   <td><?php echo e($user->mnethostid); ?></td>
   <td><a href="<?php echo e(route('datas.show',$user->id)); ?>" class = "btn btn-info">Show Course</a></td>
   <?php if($user->mnethostid && $user->confirmed): ?>
   <td style= "color:green"><a href="http://localhost/moodle/login/index.php" class = "btn btn-primary">Login in moodle</a></td>
   <?php else: ?>
   <td style= "color:red; text-decorition:line-thrugh"><span>you are not have authntecity</span></td>
   <?php endif; ?>
   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>