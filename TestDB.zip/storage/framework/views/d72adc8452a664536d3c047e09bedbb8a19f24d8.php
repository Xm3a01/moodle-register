<?php $__env->startSection('content'); ?>

  <table class="table col-md-10 offset-md-1 showusers">
   <thead>
    <tr>
    <th>Full name</th>
    <th>Short name</th>
    </tr>
  </thead>
  <tbody>
   <tr>
   <td><?php echo e($course->firstname); ?></td>
   <td><?php echo e($course->lastname); ?></td>
   </tr>
  </tbody>
  </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>